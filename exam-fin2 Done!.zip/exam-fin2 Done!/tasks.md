## Header component
* Make Header be a new component.
* Make the Header component have its own CSS module, adjust the classnames and CSS rules applying to it accordingly.

## Dynamic list item components
* Import "flight-data.js", save the array to a state. 
* Map over the elements of that state, and replace the hardcoded
data inside the \<ul\>'s \<li\> elements with dynamic data.
To keep the exercise simple, can use the "flightNumber" as "Key" and also assume that is should be unique. You should not handle the case when a user submits a flight with the same number. 
* If a given flight is a charter, that \<li\> should have a "2px dashed red" border.
* Make those \<li\> elements their own components (FlightListItem component).
* Clicking on the "X" button in a FlightListItem should remove that item from the list (from the flights state in App.js). Create the function doing so (maybe using filter or splice) in App.js and pass it as a prop to the FlightListItem.
* If the list is empty, display an \<h1\> saying so.

## "Login" functionality
* Have a state in App.js [loggedIn, setLoggedIn]. The default state should be "false". Pass those over to the Header component for use.
* The "Login" button should flip the logged in state on click (if true, set it to false and vice versa).
* Based on the same state, the "Login" button should say either "Login" or "Logout".
* The "Add" button should be disabled if the user is not logged in. Enabled otherwise.

## Flight add form component
* Make the flight add form its own component.
You can use the elements as is, or wrap them with a form component if you want to. You can use states, refs, just grabbing the values with plain javascript, whatever you prefer.
* It should work as expected, properly adding elements to the flights state in App.js.
* It should have some basic validation: all fields are requird, and the flight type can be either "scheduled", "charter" or "private". If the user types something else, when clicking the "Add" button, the submission should fail, displaying some form of message or alert.
* Optional bonus task for extra points: Validate whether the flightNumber supplied by the user is already present in the big flight state in App.js.
* Optional bonus task for extra points: Make the flight type a dropdown menu containing these three values.
