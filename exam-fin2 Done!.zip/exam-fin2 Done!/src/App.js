import Header from "./components/Header";
import React from "react";
import flight_data from "./flight_data";
import { useState, useEffect } from 'react';
import FlightListItem from "./components/FlightListItem";
import FlightForm from "./components/FlightForm";

function App() {

  const [flights, setFlights] = useState([
    { flightNumber: 'EK261', flightDate: '2024.05.02', flightType: 'scheduled' }
    
  ]);

  const removeFlight = (flightNumber) => {
    setFlights(flights.filter(flight => flight.flightNumber !== flightNumber));
  };

  const [loggedIn, setLoggedIn] = useState(false);

  const addFlight = (flight) => {
    setFlights([...flights, flight]);
  };

   useEffect(() => {
     setFlights(flight_data);
   }, []);

  return (
    <>
      <Header loggedIn={loggedIn} setLoggedIn={setLoggedIn}/>

      <FlightForm loggedIn={loggedIn} addFlight={addFlight} flights={flights}/>

      <main>
      {flights.length === 0 ? (
          <h1>No flights available</h1>
        ) : (
          <ul id="flightList">
            {flights.map((flight, index) => (
                <FlightListItem 
                  key={index}
                  flightNumber={flight.flightNumber}
                  flightDate={flight.flightDate}
                  flightType={flight.flightType}
                  onRemove={removeFlight}
              />
            ))}
            </ul>
          )
          }   
      </main>
    </>
  );
}

export default App;
