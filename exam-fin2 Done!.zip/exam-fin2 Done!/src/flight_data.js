const flight_data = [
    {
        flightNumber: "AA123",
        flightDate: "2024-07-10",
        flightType: "scheduled"
    },
    {
        flightNumber: "BA456",
        flightDate: "2024-07-12",
        flightType: "charter"
    },
    {
        flightNumber: "CA789",
        flightDate: "2024-07-14",
        flightType: "private"
    },
    {
        flightNumber: "DL101",
        flightDate: "2024-07-16",
        flightType: "scheduled"
    },
    {
        flightNumber: "EK202",
        flightDate: "2024-07-18",
        flightType: "charter"
    },
    {
        flightNumber: "AF303",
        flightDate: "2024-07-20",
        flightType: "private"
    }
];

export default flight_data;