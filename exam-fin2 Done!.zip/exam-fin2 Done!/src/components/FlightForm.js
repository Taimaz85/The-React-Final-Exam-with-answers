import { useState } from "react";
import React from "react";


const FlightForm = ({ loggedIn, addFlight, flights}) => {
    const [flightNumber, setFlightNumber] = useState('');
    const [flightDate, setFlightDate] = useState('');
    const [flightType, setFlightType] = useState('');
    const [error, setError] = useState('');
  
    const handleAddFlight = () => {
      if (flightNumber && flightDate && flightType) {
        addFlight({ flightNumber, flightDate, flightType });
        setFlightNumber('');
        setFlightDate('');
        setFlightType('');
      }
      else if (!flightNumber || !flightDate || !flightType) {
        setError('All fields are required.');
        return;
      }
      const allowedFlightTypes = ['scheduled', 'charter', 'private'];
      if (!allowedFlightTypes.includes(flightType.toLowerCase())) {
        setError('Flight type must be one of: scheduled, charter, private.');
        return;
      }

      if (flights.some(flight => flight.flightNumber === flightNumber)) {
        setError('Flight number already exists.');
        return;
      }
  
      addFlight({ flightNumber, flightDate, flightType });
      setFlightNumber('');
      setFlightDate('');
      setFlightType('');
      setError('');
    };

    return (
        <div className="flightForm">
                <div className="flightFormContent">
                <label htmlFor="flightNumber">Flight number</label>
                <input type="text" name="flightNumber" id="flighNumber" value={flightNumber}
                    onChange={(e) => setFlightNumber(e.target.value)}/>
                <label htmlFor="flightDate">Date</label>
                <input type="date" name="flightDate" id="flightDate" value={flightDate}
                    onChange={(e) => setFlightDate(e.target.value)}/>
                <label htmlFor="flightType">
                    Flight type
                </label>
                <select 
                    name="flightType" 
                    id="flightType" 
                    value={flightType}
                    onChange={(e) => setFlightType(e.target.value)}
                >
                    <option value="">Select a type</option>
                    <option value="scheduled">Scheduled</option>
                    <option value="charter">Charter</option>
                    <option value="private">Private</option>
                </select>
                {/* <input type="text" name="flightType" id="flighType" value={flightType}
                    onChange={(e) => setFlightType(e.target.value)}/> */}
                </div>
                {error && <div className="error">{error}</div>}
                <div className="flightFormActions">
                <button id="addFlight" disabled={!loggedIn} onClick={handleAddFlight}>
                    Add
                </button>
                <button id="cancelFlight" onClick={() => {
                    setFlightNumber('');
                    setFlightDate('');
                    setFlightType('');
                    setError('');
                }}>Cancel</button>
                </div>
        </div>

    );
};

export default FlightForm;