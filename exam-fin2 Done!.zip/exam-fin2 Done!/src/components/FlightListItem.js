import React from "react";


const FlightListItem = ({ flightNumber, flightDate, flightType, onRemove }) => {
    return (
        <li 
            key={flightNumber} 
            className="flightElement"
            style={flightType === 'charter' ? 
            { border: '2px dashed red' }:{}}
            >
            <h2>{flightNumber}</h2>
            <h4>{flightDate}</h4>
            <h5>{flightType}</h5>
            <button onClick={() => onRemove(flightNumber)}>X</button>
        </li>
    );
};

export default FlightListItem;
