import React from 'react';
import './Header.css';

    const Header = ({ loggedIn, setLoggedIn}) => {

  return (
    <header className="headerWrapper">
      <div className="headerInner">
        <span className="title">Flights</span>
        {loggedIn ? (
        <button className="login" onClick={() => setLoggedIn(false)}>Login</button>
        ) : (
        <button className="login" onClick={() => setLoggedIn(true)}>Logout</button>
        )}
      </div>
    </header>
  );
}

export default Header;
